package com.curso.demo.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class Carta {
    
    @JsonProperty("Set")
    private String set;
    
    @JsonProperty("Number")
    private String number;
    
    @JsonProperty("Name")
    private String name;
    
    @JsonProperty("Type")
    private String type;
    
    @JsonProperty("Aspects")
    private List<String> aspects;
    
    @JsonProperty("Traits")
    private List<String> traits;
    
    @JsonProperty("Arenas")
    private List<String> arenas;
    
    @JsonProperty("Rarity")
    private String rarity;
    
    @JsonProperty("MarketPrice")
    private String marketPrice;
    
    @JsonProperty("FrontArt")
    private String frontArt;
    
    // Constructor vacío
    public Carta() {}
    
    // Constructor con parámetros
    public Carta(String set, String number, String name, String type, 
                List<String> aspects, List<String> traits, List<String> arenas, 
                String rarity, String marketPrice, String frontArt) {
        this.set = set;
        this.number = number;
        this.name = name;
        this.type = type;
        this.aspects = aspects;
        this.traits = traits;
        this.arenas = arenas;
        this.rarity = rarity;
        this.marketPrice = marketPrice;
        this.frontArt = frontArt;
    }
    
    // Getters y Setters
    public String getSet() {
        return set;
    }
    
    public void setSet(String set) {
        this.set = set;
    }
    
    public String getNumber() {
        return number;
    }
    
    public void setNumber(String number) {
        this.number = number;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public List<String> getAspects() {
        return aspects;
    }
    
    public void setAspects(List<String> aspects) {
        this.aspects = aspects;
    }
    
    public List<String> getTraits() {
        return traits;
    }
    
    public void setTraits(List<String> traits) {
        this.traits = traits;
    }
    
    public List<String> getArenas() {
        return arenas;
    }
    
    public void setArenas(List<String> arenas) {
        this.arenas = arenas;
    }
    
    public String getRarity() {
        return rarity;
    }
    
    public void setRarity(String rarity) {
        this.rarity = rarity;
    }
    
    public String getMarketPrice() {
        return marketPrice;
    }
    
    public void setMarketPrice(String marketPrice) {
        this.marketPrice = marketPrice;
    }
    
    public String getFrontArt() {
        return frontArt;
    }
    
    public void setFrontArt(String frontArt) {
        this.frontArt = frontArt;
    }
    
    // Método para obtener un ID único
    public String getId() {
        return set + "-" + number;
    }
    
    // Método para obtener el precio formateado
    public String getFormattedPrice() {
        try {
            double price = Double.parseDouble(marketPrice);
            return String.format("%.2f", price);
        } catch (NumberFormatException e) {
            return "0.00";
        }
    }
    
    @Override
    public String toString() {
        return "Carta{" +
                "set='" + set + '\'' +
                ", number='" + number + '\'' +
                ", name='" + name + '\'' +
                ", type='" + type + '\'' +
                ", rarity='" + rarity + '\'' +
                ", marketPrice='" + marketPrice + '\'' +
                '}';
    }
}
