package com.curso.demo.controllers;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.curso.demo.models.Empleados;
import com.curso.demo.models.dto.ClaseDTO;


//Api rest: interfaz que permite la comunicacion entre sistemas
//RestController: indica que la clase es un controlador donde cada metodo devuelve un objeto de dominio

@RestController // indica que la clase es un controlador donde cada metodo devuelve un objeto de dominio
@RequestMapping("/api") //RequestMapping: mapea las solicitudes web a clases o metodos especificos

public class EjemploRestController {

    @GetMapping(path = "/detalles_info2")
    
    public ClaseDTO detalless_info2() {
        ClaseDTO usuario1 = new ClaseDTO();
        usuario1.setTitulo("Adminisitrador");
        usuario1.setUsuario("informaticonfig");


        return usuario1; 
    }

}
