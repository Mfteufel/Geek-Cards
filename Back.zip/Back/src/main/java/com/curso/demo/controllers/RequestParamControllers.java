package com.curso.demo.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping("/api/parametros")
public class RequestParamControllers {

    @GetMapping("/detalle")
    public ParametroDto detalle(@RequestParam(required = false, defaultValue = "Hola a todos") String informacion){
        ParametroDto parametro1 = new ParametroDto();
        parametro1.setInformacion(informacion);
        return parametro1;
    }

}
