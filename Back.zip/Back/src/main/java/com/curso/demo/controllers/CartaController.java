package com.curso.demo.controllers;

import com.curso.demo.models.Carta;
import com.curso.demo.models.dto.ApiResponse;
import com.curso.demo.services.CartaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/cartas")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173", "http://127.0.0.1:3000", "http://127.0.0.1:5173"})
public class CartaController {
    
    @Autowired
    private CartaService cartaService;
    
    /**
     * Obtener todas las cartas
     */
    @GetMapping
    public ResponseEntity<ApiResponse<List<Carta>>> getAllCartas() {
        try {
            List<Carta> cartas = cartaService.getAllCards();
            System.out.println("🃏 [CARDS] Enviando " + cartas.size() + " cartas");
            return ResponseEntity.ok(ApiResponse.success("Cartas obtenidas exitosamente", cartas));
        } catch (Exception e) {
            System.err.println("💥 [CARDS] Error al obtener cartas: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error al obtener cartas", e.getMessage()));
        }
    }
    
    /**
     * Buscar cartas con filtros
     */
    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<Carta>>> searchCartas(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) String aspect,
            @RequestParam(required = false) String trait,
            @RequestParam(required = false) String arena,
            @RequestParam(required = false) String rarity) {
        
        try {
            System.out.println("🔍 [SEARCH] Buscando cartas con filtros:");
            System.out.println("  - Search: " + search);
            System.out.println("  - Type: " + type);
            System.out.println("  - Aspect: " + aspect);
            System.out.println("  - Trait: " + trait);
            System.out.println("  - Arena: " + arena);
            System.out.println("  - Rarity: " + rarity);
            
            List<Carta> cartas = cartaService.searchCards(search, type, aspect, trait, arena, rarity);
            
            System.out.println("✅ [SEARCH] Encontradas " + cartas.size() + " cartas");
            return ResponseEntity.ok(ApiResponse.success("Búsqueda completada", cartas));
        } catch (Exception e) {
            System.err.println("💥 [SEARCH] Error en búsqueda: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error en la búsqueda", e.getMessage()));
        }
    }
    
    /**
     * Obtener carta por ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Carta>> getCartaById(@PathVariable String id) {
        try {
            System.out.println("🃏 [CARD] Buscando carta con ID: " + id);
            Optional<Carta> carta = cartaService.findById(id);
            
            if (carta.isPresent()) {
                System.out.println("✅ [CARD] Carta encontrada: " + carta.get().getName());
                return ResponseEntity.ok(ApiResponse.success("Carta encontrada", carta.get()));
            } else {
                System.out.println("❌ [CARD] Carta no encontrada: " + id);
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(ApiResponse.error("Carta no encontrada"));
            }
        } catch (Exception e) {
            System.err.println("💥 [CARD] Error al buscar carta: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error al buscar carta", e.getMessage()));
        }
    }
    
    /**
     * Obtener cartas por expansión
     */
    @GetMapping("/expansion/{expansionCode}")
    public ResponseEntity<ApiResponse<List<Carta>>> getCartasByExpansion(@PathVariable String expansionCode) {
        try {
            System.out.println("📦 [EXPANSION] Buscando cartas de expansión: " + expansionCode);
            List<Carta> cartas = cartaService.getCardsByExpansion(expansionCode);
            System.out.println("✅ [EXPANSION] Encontradas " + cartas.size() + " cartas en " + expansionCode);
            return ResponseEntity.ok(ApiResponse.success("Cartas de expansión obtenidas", cartas));
        } catch (Exception e) {
            System.err.println("💥 [EXPANSION] Error al obtener cartas de expansión: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error al obtener cartas de expansión", e.getMessage()));
        }
    }
    
    /**
     * Obtener todos los tipos disponibles
     */
    @GetMapping("/types")
    public ResponseEntity<ApiResponse<List<String>>> getAllTypes() {
        try {
            List<String> types = cartaService.getAllTypes();
            return ResponseEntity.ok(ApiResponse.success("Tipos obtenidos", types));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error al obtener tipos", e.getMessage()));
        }
    }
    
    /**
     * Obtener todas las rarezas disponibles
     */
    @GetMapping("/rarities")
    public ResponseEntity<ApiResponse<List<String>>> getAllRarities() {
        try {
            List<String> rarities = cartaService.getAllRarities();
            return ResponseEntity.ok(ApiResponse.success("Rarezas obtenidas", rarities));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error al obtener rarezas", e.getMessage()));
        }
    }
    
    /**
     * Obtener todos los aspectos disponibles
     */
    @GetMapping("/aspects")
    public ResponseEntity<ApiResponse<List<String>>> getAllAspects() {
        try {
            List<String> aspects = cartaService.getAllAspects();
            return ResponseEntity.ok(ApiResponse.success("Aspectos obtenidos", aspects));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error al obtener aspectos", e.getMessage()));
        }
    }
    
    /**
     * Obtener todos los traits disponibles
     */
    @GetMapping("/traits")
    public ResponseEntity<ApiResponse<List<String>>> getAllTraits() {
        try {
            List<String> traits = cartaService.getAllTraits();
            return ResponseEntity.ok(ApiResponse.success("Traits obtenidos", traits));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error al obtener traits", e.getMessage()));
        }
    }
    
    /**
     * Obtener todas las arenas disponibles
     */
    @GetMapping("/arenas")
    public ResponseEntity<ApiResponse<List<String>>> getAllArenas() {
        try {
            List<String> arenas = cartaService.getAllArenas();
            return ResponseEntity.ok(ApiResponse.success("Arenas obtenidas", arenas));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error al obtener arenas", e.getMessage()));
        }
    }
    
    /**
     * Obtener estadísticas de las cartas
     */
    @GetMapping("/stats")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getStats() {
        try {
            Map<String, Object> stats = cartaService.getStats();
            return ResponseEntity.ok(ApiResponse.success("Estadísticas obtenidas", stats));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error al obtener estadísticas", e.getMessage()));
        }
    }
}
