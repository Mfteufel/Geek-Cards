package com.curso.demo.services;

import com.curso.demo.models.Carta;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import jakarta.annotation.PostConstruct;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class CartaService {
    
    private final String CARDS_FILE_PATH = "data/swu_todas_por_expansion.json";
    private final ObjectMapper objectMapper = new ObjectMapper();
    private List<Carta> allCards = new ArrayList<>();
    
    @PostConstruct
    public void init() {
        loadCardsFromFile();
    }
    
    /**
     * Cargar todas las cartas desde el archivo JSON
     */
    private void loadCardsFromFile() {
        try {
            File file = new File(CARDS_FILE_PATH);
            if (file.exists()) {
                System.out.println("🃏 [CARDS] Cargando cartas desde: " + CARDS_FILE_PATH);
                
                JsonNode rootNode = objectMapper.readTree(file);
                allCards = new ArrayList<>();
                
                // Iterar sobre cada expansión
                Iterator<Map.Entry<String, JsonNode>> fields = rootNode.fields();
                while (fields.hasNext()) {
                    Map.Entry<String, JsonNode> entry = fields.next();
                    String expansionCode = entry.getKey();
                    JsonNode expansionData = entry.getValue();
                    
                    if (expansionData.has("cards") && expansionData.get("cards").has("data")) {
                        JsonNode cardsArray = expansionData.get("cards").get("data");
                        
                        for (JsonNode cardNode : cardsArray) {
                            try {
                                Carta carta = objectMapper.treeToValue(cardNode, Carta.class);
                                allCards.add(carta);
                            } catch (Exception e) {
                                System.err.println("Error procesando carta: " + e.getMessage());
                            }
                        }
                    }
                }
                
                System.out.println("✅ [CARDS] Cargadas " + allCards.size() + " cartas exitosamente");
            } else {
                System.err.println("❌ [CARDS] Archivo no encontrado: " + CARDS_FILE_PATH);
            }
        } catch (IOException e) {
            System.err.println("💥 [CARDS] Error al cargar cartas: " + e.getMessage());
        }
    }
    
    /**
     * Obtener todas las cartas
     */
    public List<Carta> getAllCards() {
        return new ArrayList<>(allCards);
    }
    
    /**
     * Buscar cartas por criterios
     */
    public List<Carta> searchCards(String searchTerm, String type, String aspect, 
                                 String trait, String arena, String rarity) {
        return allCards.stream()
                .filter(card -> matchesSearchTerm(card, searchTerm))
                .filter(card -> matchesType(card, type))
                .filter(card -> matchesAspect(card, aspect))
                .filter(card -> matchesTrait(card, trait))
                .filter(card -> matchesArena(card, arena))
                .filter(card -> matchesRarity(card, rarity))
                .collect(Collectors.toList());
    }
    
    /**
     * Buscar cartas por término de búsqueda (nombre)
     */
    private boolean matchesSearchTerm(Carta card, String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return true;
        }
        return card.getName().toLowerCase().contains(searchTerm.toLowerCase());
    }
    
    /**
     * Filtrar por tipo
     */
    private boolean matchesType(Carta card, String type) {
        if (type == null || type.trim().isEmpty() || "Todos".equals(type)) {
            return true;
        }
        return type.equals(card.getType());
    }
    
    /**
     * Filtrar por aspecto
     */
    private boolean matchesAspect(Carta card, String aspect) {
        if (aspect == null || aspect.trim().isEmpty() || "Todos".equals(aspect)) {
            return true;
        }
        return card.getAspects() != null && card.getAspects().contains(aspect);
    }
    
    /**
     * Filtrar por trait
     */
    private boolean matchesTrait(Carta card, String trait) {
        if (trait == null || trait.trim().isEmpty() || "Todos".equals(trait)) {
            return true;
        }
        return card.getTraits() != null && card.getTraits().contains(trait);
    }
    
    /**
     * Filtrar por arena
     */
    private boolean matchesArena(Carta card, String arena) {
        if (arena == null || arena.trim().isEmpty() || "Todos".equals(arena)) {
            return true;
        }
        return card.getArenas() != null && card.getArenas().contains(arena);
    }
    
    /**
     * Filtrar por rareza
     */
    private boolean matchesRarity(Carta card, String rarity) {
        if (rarity == null || rarity.trim().isEmpty() || "Todas".equals(rarity)) {
            return true;
        }
        return rarity.equals(card.getRarity());
    }
    
    /**
     * Obtener carta por ID único
     */
    public Optional<Carta> findById(String id) {
        return allCards.stream()
                .filter(card -> card.getId().equals(id))
                .findFirst();
    }
    
    /**
     * Obtener cartas por expansión
     */
    public List<Carta> getCardsByExpansion(String expansionCode) {
        return allCards.stream()
                .filter(card -> card.getSet().equals(expansionCode))
                .collect(Collectors.toList());
    }
    
    /**
     * Obtener todos los tipos únicos
     */
    public List<String> getAllTypes() {
        return allCards.stream()
                .map(Carta::getType)
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }
    
    /**
     * Obtener todas las rarezas únicas
     */
    public List<String> getAllRarities() {
        return allCards.stream()
                .map(Carta::getRarity)
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }
    
    /**
     * Obtener todos los aspectos únicos
     */
    public List<String> getAllAspects() {
        return allCards.stream()
                .flatMap(card -> card.getAspects() != null ? card.getAspects().stream() : Stream.empty())
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }
    
    /**
     * Obtener todos los traits únicos
     */
    public List<String> getAllTraits() {
        return allCards.stream()
                .flatMap(card -> card.getTraits() != null ? card.getTraits().stream() : Stream.empty())
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }
    
    /**
     * Obtener todas las arenas únicas
     */
    public List<String> getAllArenas() {
        return allCards.stream()
                .flatMap(card -> card.getArenas() != null ? card.getArenas().stream() : Stream.empty())
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }
    
    /**
     * Obtener estadísticas de las cartas
     */
    public Map<String, Object> getStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalCards", allCards.size());
        stats.put("totalTypes", getAllTypes().size());
        stats.put("totalRarities", getAllRarities().size());
        stats.put("totalAspects", getAllAspects().size());
        stats.put("totalTraits", getAllTraits().size());
        stats.put("totalArenas", getAllArenas().size());
        return stats;
    }
}
