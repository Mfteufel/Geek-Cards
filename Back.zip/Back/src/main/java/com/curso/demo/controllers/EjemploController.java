package com.curso.demo.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.curso.demo.models.Empleados;

@Controller
public class EjemploController {

    @GetMapping("/detalles_info")
    
    public String info(Model model) {
        Empleados empleado1 = new Empleados("Juan", "Rodriguez", "Calle 1ra No1", "Gerente", 35, 123456789, 1);

        model.addAttribute("Empleado", empleado1); // model es un contenedor de datos


        return "detalles_info"; // retorna el nombre de la vista (detalles_info.html)
    }

}
