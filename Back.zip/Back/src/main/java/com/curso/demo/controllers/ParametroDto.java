package com.curso.demo.controllers;

public class ParametroDto {
    private String informacion;

    public String getInformacion() {
        return informacion;
    }

    public void setInformacion(String informacion) {
        this.informacion = informacion;
    }
}
