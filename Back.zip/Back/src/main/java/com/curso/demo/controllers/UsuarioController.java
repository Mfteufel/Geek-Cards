package com.curso.demo.controllers;

import com.curso.demo.models.Usuario;
import com.curso.demo.models.dto.ApiResponse;
import com.curso.demo.models.dto.LoginRequest;
import com.curso.demo.models.dto.RegisterRequest;
import com.curso.demo.services.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173", "http://127.0.0.1:3000", "http://127.0.0.1:5173"})
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    /**
     * Registrar un nuevo usuario
     */
    @PostMapping("/register")
    public ResponseEntity<ApiResponse<Usuario>> registrarUsuario(@Valid @RequestBody RegisterRequest request) {
        System.out.println("🆕 [REGISTER] Intentando registrar usuario: " + request.getEmail());
        try {
            Usuario nuevoUsuario = usuarioService.registrarUsuario(request);
            System.out.println("✅ [REGISTER] Usuario registrado exitosamente: " + nuevoUsuario.getId());
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success("Usuario registrado exitosamente", nuevoUsuario));
        } catch (RuntimeException e) {
            System.out.println("❌ [REGISTER] Error: " + e.getMessage());
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        } catch (Exception e) {
            System.out.println("💥 [REGISTER] Error interno: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error interno del servidor", e.getMessage()));
        }
    }

    /**
     * Iniciar sesión
     */
    @PostMapping("/login")
    public ResponseEntity<ApiResponse<Usuario>> login(@Valid @RequestBody LoginRequest request) {
        System.out.println("🔐 [LOGIN] Intentando login para: " + request.getEmail());
        try {
            Usuario usuario = usuarioService.autenticarUsuario(request.getEmail(), request.getPassword());
            System.out.println("✅ [LOGIN] Login exitoso para: " + usuario.getName());
            return ResponseEntity.ok(ApiResponse.success("Login exitoso", usuario));
        } catch (RuntimeException e) {
            System.out.println("❌ [LOGIN] Error de autenticación: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error(e.getMessage()));
        } catch (Exception e) {
            System.out.println("💥 [LOGIN] Error interno: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error interno del servidor", e.getMessage()));
        }
    }

    /**
     * Obtener todos los usuarios
     */
    @GetMapping
    public ResponseEntity<ApiResponse<List<Usuario>>> getAllUsuarios() {
        try {
            List<Usuario> usuarios = usuarioService.getAllUsuarios();
            return ResponseEntity.ok(ApiResponse.success("Usuarios obtenidos exitosamente", usuarios));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error al obtener usuarios", e.getMessage()));
        }
    }

    /**
     * Obtener usuario por ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Usuario>> getUsuarioById(@PathVariable Long id) {
        try {
            return usuarioService.findById(id)
                    .map(usuario -> ResponseEntity.ok(ApiResponse.success("Usuario encontrado", usuario)))
                    .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND)
                            .body(ApiResponse.error("Usuario no encontrado")));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error al obtener usuario", e.getMessage()));
        }
    }

    /**
     * Actualizar usuario
     */
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Usuario>> actualizarUsuario(@PathVariable Long id, @Valid @RequestBody Usuario usuario) {
        try {
            Usuario usuarioActualizado = usuarioService.actualizarUsuario(id, usuario);
            return ResponseEntity.ok(ApiResponse.success("Usuario actualizado exitosamente", usuarioActualizado));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(ApiResponse.error(e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error al actualizar usuario", e.getMessage()));
        }
    }

    /**
     * Eliminar usuario
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<String>> eliminarUsuario(@PathVariable Long id) {
        try {
            boolean eliminado = usuarioService.eliminarUsuario(id);
            if (eliminado) {
                return ResponseEntity.ok(ApiResponse.success("Usuario eliminado exitosamente"));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(ApiResponse.error("Usuario no encontrado"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error al eliminar usuario", e.getMessage()));
        }
    }

    /**
     * Verificar si un email existe
     */
    @GetMapping("/check-email")
    public ResponseEntity<ApiResponse<Boolean>> checkEmail(@RequestParam String email) {
        try {
            boolean exists = usuarioService.findByEmail(email).isPresent();
            return ResponseEntity.ok(ApiResponse.success("Verificación completada", exists));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("Error al verificar email", e.getMessage()));
        }
    }
}
