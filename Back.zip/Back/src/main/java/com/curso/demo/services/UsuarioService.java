package com.curso.demo.services;

import com.curso.demo.models.Usuario;
import com.curso.demo.models.dto.RegisterRequest;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.annotation.PostConstruct;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class UsuarioService {
    
    @Autowired
    private PasswordService passwordService;
    
    private final String USERS_FILE_PATH = "data/users.json";
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final AtomicLong idGenerator = new AtomicLong(1);
    private List<Usuario> usuarios = new ArrayList<>();

    public UsuarioService() {
        // No llamar loadUsersFromFile() aquí
        // Se llamará después de que Spring inyecte las dependencias
    }

    @PostConstruct
    public void init() {
        loadUsersFromFile();
    }

    /**
     * Cargar usuarios desde el archivo JSON
     */
    private void loadUsersFromFile() {
        try {
            File file = new File(USERS_FILE_PATH);
            if (file.exists()) {
                usuarios = objectMapper.readValue(file, new TypeReference<List<Usuario>>() {});
                // Actualizar el generador de IDs con el máximo ID existente
                usuarios.stream()
                    .mapToLong(Usuario::getId)
                    .max()
                    .ifPresent(maxId -> idGenerator.set(maxId + 1));
            } else {
                // Crear directorio si no existe
                file.getParentFile().mkdirs();
                // Crear usuario demo por defecto
                createDefaultUsers();
            }
        } catch (IOException e) {
            System.err.println("Error al cargar usuarios: " + e.getMessage());
            createDefaultUsers();
        }
    }

    /**
     * Guardar usuarios en el archivo JSON
     */
    private void saveUsersToFile() {
        try {
            File file = new File(USERS_FILE_PATH);
            file.getParentFile().mkdirs();
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(file, usuarios);
        } catch (IOException e) {
            System.err.println("Error al guardar usuarios: " + e.getMessage());
        }
    }

    /**
     * Crear usuarios por defecto
     */
    private void createDefaultUsers() {
        usuarios = new ArrayList<>();
        // Usar contraseña sin hashear para el usuario demo inicial
        // Se hasheará cuando se haga login por primera vez
        Usuario demoUser = new Usuario("Usuario Demo", "demo@geekcards.com", "12345678");
        demoUser.setId(idGenerator.getAndIncrement());
        usuarios.add(demoUser);
        saveUsersToFile();
    }

    /**
     * Registrar un nuevo usuario
     */
    public Usuario registrarUsuario(RegisterRequest request) {
        // Verificar si el email ya existe
        if (findByEmail(request.getEmail()).isPresent()) {
            throw new RuntimeException("Ya existe una cuenta con este email");
        }

        // Verificar que las contraseñas coincidan
        if (!request.getPassword().equals(request.getPasswordConfirm())) {
            throw new RuntimeException("Las contraseñas no coinciden");
        }

        // Crear nuevo usuario con contraseña hasheada
        Usuario nuevoUsuario = new Usuario(request.getName(), request.getEmail(), passwordService.hashPassword(request.getPassword()));
        nuevoUsuario.setId(idGenerator.getAndIncrement());
        
        usuarios.add(nuevoUsuario);
        saveUsersToFile();
        
        return nuevoUsuario;
    }

    /**
     * Buscar usuario por email
     */
    public Optional<Usuario> findByEmail(String email) {
        return usuarios.stream()
                .filter(usuario -> usuario.getEmail().equals(email))
                .findFirst();
    }

    /**
     * Buscar usuario por ID
     */
    public Optional<Usuario> findById(Long id) {
        return usuarios.stream()
                .filter(usuario -> usuario.getId().equals(id))
                .findFirst();
    }

    /**
     * Autenticar usuario (login)
     */
    public Usuario autenticarUsuario(String email, String password) {
        Optional<Usuario> usuarioOpt = findByEmail(email);
        
        if (usuarioOpt.isPresent()) {
            Usuario usuario = usuarioOpt.get();
            
            // Verificar si la contraseña está hasheada o no
            if (usuario.getPassword().startsWith("$2a$") || usuario.getPassword().startsWith("$2b$")) {
                // Contraseña hasheada - usar BCrypt
                if (passwordService.verifyPassword(password, usuario.getPassword())) {
                    return usuario;
                }
            } else {
                // Contraseña sin hashear - comparación directa (para usuario demo)
                if (usuario.getPassword().equals(password)) {
                    // Hashear la contraseña y actualizar el usuario
                    usuario.setPassword(passwordService.hashPassword(password));
                    saveUsersToFile();
                    return usuario;
                }
            }
        }
        
        throw new RuntimeException("Email o contraseña incorrectos");
    }

    /**
     * Obtener todos los usuarios
     */
    public List<Usuario> getAllUsuarios() {
        return new ArrayList<>(usuarios);
    }

    /**
     * Actualizar usuario
     */
    public Usuario actualizarUsuario(Long id, Usuario usuarioActualizado) {
        Optional<Usuario> usuarioOpt = findById(id);
        
        if (usuarioOpt.isPresent()) {
            Usuario usuario = usuarioOpt.get();
            usuario.setName(usuarioActualizado.getName());
            usuario.setEmail(usuarioActualizado.getEmail());
            usuario.setUpdatedAt(java.time.LocalDateTime.now());
            
            saveUsersToFile();
            return usuario;
        }
        
        throw new RuntimeException("Usuario no encontrado");
    }

    /**
     * Eliminar usuario
     */
    public boolean eliminarUsuario(Long id) {
        boolean removed = usuarios.removeIf(usuario -> usuario.getId().equals(id));
        if (removed) {
            saveUsersToFile();
        }
        return removed;
    }
}
