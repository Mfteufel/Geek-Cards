package com.curso.demo.controllers;

import com.curso.demo.models.Usuario;
import com.curso.demo.services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/logs")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173", "http://127.0.0.1:3000", "http://127.0.0.1:5173"})
public class LogController {

    @Autowired
    private UsuarioService usuarioService;

    /**
     * Endpoint para ver todos los usuarios (para debugging)
     */
    @GetMapping("/usuarios")
    public List<Usuario> getAllUsuarios() {
        System.out.println("🔍 [LOG] Consultando todos los usuarios");
        List<Usuario> usuarios = usuarioService.getAllUsuarios();
        System.out.println("📊 [LOG] Total de usuarios encontrados: " + usuarios.size());
        return usuarios;
    }

    /**
     * Endpoint para ver el estado del servidor
     */
    @GetMapping("/status")
    public String getStatus() {
        System.out.println("✅ [LOG] Verificando estado del servidor");
        return "Servidor funcionando correctamente - " + java.time.LocalDateTime.now();
    }

    /**
     * Endpoint para ver logs de peticiones
     */
    @GetMapping("/requests")
    public String getRequestLogs() {
        System.out.println("📝 [LOG] Consultando logs de peticiones");
        return "Logs de peticiones disponibles en la consola del servidor";
    }
}
